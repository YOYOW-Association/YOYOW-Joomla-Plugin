<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Yoyow
 * @author     Pablo <pablojuarez@notwebdesign.com>
 * @copyright  2018 Pablo
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access.
defined('_JEXEC') or die;

jimport('joomla.application.component.modeladmin');

/**
 * Yoyow model.
 *
 * @since  1.6
 */
class YoyowModelJoomlauser_yoyowuser extends JModelAdmin
{
	public function getForm ($data = array(), $loadData = true)
	{
	
	}
}
